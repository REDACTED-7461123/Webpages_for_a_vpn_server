REPUBLIC OF ALEX

Open index.html in your browser. No installation, build, or internet needed.

Add your own images at these exact paths relative to index.html:
  images/flag/flag.png
  images/president/president.jpg

The images are intentionally not included. Until you add them, their alt text
will appear in the reserved image areas. You can also edit the img src paths
in index.html to use different names or file formats.

Edit the country name, president's name, descriptions, and motto in index.html.
If you rename them, update the image alt text, page title, and description too.
Change the color variables at the beginning of styles.css to change the theme.
Adjust object-position in .portrait-image if your portrait needs a different crop.

This one-page website uses only HTML and CSS. It includes responsive layouts,
smooth anchor scrolling, staggered entrance animations, card hover effects,
image transitions, keyboard focus styles, and reduced-motion support.
